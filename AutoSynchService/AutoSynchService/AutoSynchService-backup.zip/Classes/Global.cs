﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoSynchService.Classes
{
    public static class Global
    {
        public static int BranchId { get; set; }       

    }
}
